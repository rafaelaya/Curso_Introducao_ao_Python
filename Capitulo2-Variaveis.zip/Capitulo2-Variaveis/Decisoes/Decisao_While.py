numero=int(input("Digite um numero: "))
while numero<100:
    print("\t" + str(numero))
    numero=numero+1
    print("Laço encerrado....")